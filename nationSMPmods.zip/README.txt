Hello, to start. You will need  Forge 1.16.4. Which can be found at the following link:
https://files.minecraftforge.net/

or you can just click on this link and download it. 
https://files.minecraftforge.net/maven/net/minecraftforge/forge/1.16.4-35.1.37/forge-1.16.4-35.1.37-installer.jar

then, you will open it and click on "install client", and then click "OK".

Open minecraft with the good forge version, wait for it to load. Then click on "Mods" and then "Open Mods Folder", drag the folder .zip and right click on the folder and click "Extract all".

There you go, you can join our server now!
